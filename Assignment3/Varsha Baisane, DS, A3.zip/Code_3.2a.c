#include <stdio.h>

//Function for insertion sort
void insertionSort(int arr[], int n) {
    int i, key, j;
    //looping over entire array
    for (i = 1; i < n; i++) {
        key = arr[i]; //element to be inserted
        j = i - 1;

        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j]; // Move elements of arr[0..i-1] that are greater than key to the right by one position
            j = j - 1;
        }
        arr[j + 1] = key; // Place the current element in its correct sorted position
    }
}

int main() {
    int arr[] = {23,21,16,28,25};
    int n = sizeof(arr) / sizeof(arr[0]); //get all elements of the array

    insertionSort(arr, n);

    printf("Sorted array: \n");
    for (int i = 0; i < n; i++)
        printf("%d ", arr[i]);

    return 0;
}
