#include <stdio.h>
#include <time.h>

// Function to merge two subarrays
void merge(int arr[], int left[], int leftSize, int right[], int rightSize) {
    int i = 0, j = 0, k = 0;
    // Comparing left and right and merging them in sorted order
    while (i < leftSize && j < rightSize) {
        if (left[i] <= right[j]) {
            arr[k] = left[i];  // Place the smaller element into the original array
            i++;
        } else {
            arr[k] = right[j];
            j++;
        }
        k++;
    }

    // Copy any remaining elements from the left subarray to the original array
    while (i < leftSize) {
        arr[k] = left[i];
        i++;
        k++;
    }

    // Copy any remaining elements from the right subarray to the original array
    while (j < rightSize) {
        arr[k] = right[j];
        j++;
        k++;
    }
}

// Function to sort an array using Merge Sort
void mergeSort(int arr[], int n) {
    if (n > 1) {
        int mid = n / 2;
        int left[mid];
        int right[n - mid];
        
        // Copy elements from arr to left and right subarrays
        for (int i = 0; i < mid; i++) {
            left[i] = arr[i];
        }
        
        for (int i = mid; i < n; i++) {
            right[i - mid] = arr[i];
        }

        // Sort the left and right subarrays
        mergeSort(left, mid);
        mergeSort(right, n - mid);

        // Merge the sorted left and right subarrays to obtain the sorted array
        merge(arr, left, mid, right, n - mid);
    }
}

int main() {
    int arr[] = {82,34,90,58,97,21};
    int n = sizeof(arr) / sizeof(arr[0]);

    printf("Original Array: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    clock_t start_time = clock();
    mergeSort(arr, n);
    clock_t end_time = clock();

    double time_taken = (double)(end_time - start_time) / CLOCKS_PER_SEC;

    printf("Sorted array: \n");
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }

    printf("\nTime taken: %f seconds\n", time_taken);

    return 0;
}
