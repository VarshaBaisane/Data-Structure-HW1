#include <stdio.h>
#include <time.h>

// Function to heapify a subtree rooted with the node 'i' in the array 'arr' of size 'n'
void heapify(int arr[], int n, int i) {
    int largest = i; // Initialize the largest element as the root
    int left = 2 * i + 1; // Left child
    int right = 2 * i + 2; // Right child

    // left child larger than the root
    if (left < n && arr[left] > arr[largest]) {
        largest = left;
    }

    // right child larger than root
    if (right < n && arr[right] > arr[largest]) {
        largest = right;
    }

    // If the largest is not the root
    if (largest != i) {
        // Swap the largest with the root
        int temp = arr[i];
        arr[i] = arr[largest];
        arr[largest] = temp;

        // Recursively heapifying the affected sub-tree
        heapify(arr, n, largest);
    }
}

// Function to perform heap sort on an array 'arr' of size 'n'
void heapSort(int arr[], int n) {
    // Build a max heap from the array
    for (int i = n / 2 - 1; i >= 0; i--) {
        heapify(arr, n, i);
    }

    // Extracting elements from the heap one by one
    for (int i = n - 1; i >= 0; i--) {
        // Move the current root to the end
        int temp = arr[0];
        arr[0] = arr[i];
        arr[i] = temp;

        // Call max heapify on the reduced heap
        heapify(arr, i, 0);
    }
}

int main() {
    int arr[] = {89,90,93,74,95};
    int n = sizeof(arr) / sizeof(arr[0]);

    printf("Original Array: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    clock_t start_time = clock();
    heapSort(arr, n);
    clock_t end_time = clock();

    double time_taken = (double)(end_time - start_time) / CLOCKS_PER_SEC;

    printf("Sorted array: \n");
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }

    printf("\nTime taken: %f seconds\n", time_taken);

    return 0;
}
